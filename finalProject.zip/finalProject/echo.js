
twttr.widgets.createTimeline(
  {
    sourceType: "list",
    ownerScreenName: "TwitterDev",
    slug: "national-parks"
  },
  document.getElementById("rightbar")
);


/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function aboutMenu() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
  
  
  
$(document).ready(function(){

$('.submit').click(function(){
    validateForm();   
});

function validateForm(){
	
	var name = $('#name').val();
	var email = $('#email').val();
	var validemail = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	
	
	if(name == ""){
		alert("Please enter a name");
	}
	
	else if(name.length<2){
		alert("Your name must contain at least two characters")
	}
	
	if(email == ""){
		alert("Please enter an email");
	}
	
	else if(!validemail.test(email)){
		alert("Please enter a valid email");
	}
	
	
}


});
}
